#!/usr/bin/env python3
import subprocess
import sys
import os

def run_command(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        return result.returncode == 0
    except:
        return False

def check_tool(tool_name, install_command=None):
    print(f"Checking {tool_name}...", end=" ")
    if run_command(f"which {tool_name}"):
        print("✅")
        return True
    else:
        print("❌")
        if install_command:
            print(f"Installing {tool_name}...")
            if run_command(install_command):
                if run_command(f"which {tool_name}"):
                    print(f"{tool_name} installed successfully ✅")
                    return True
        return False

def main():
    tools = {
        "Reconnaissance Tools": {
            "subfinder": "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
            "amass": "go install -v github.com/owasp-amass/amass/v3/...@master",
            "findomain": "wget https://github.com/findomain/findomain/releases/latest/download/findomain-linux && chmod +x findomain-linux && sudo mv findomain-linux /usr/local/bin/findomain",
            "dnsx": "go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
            "altdns": "pip3 install py-altdns"
        },
        "Vulnerability Scanners": {
            "nmap": "sudo apt-get install -y nmap",
            "nuclei": "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
            "sqlmap": "git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git && sudo ln -sf $(pwd)/sqlmap/sqlmap.py /usr/local/bin/sqlmap",
            "semgrep": "pip3 install semgrep",
            "nikto": "sudo apt-get install -y nikto",
            "masscan": "sudo apt-get install -y masscan"
        },
        "Mobile Security Tools": {
            "mobsf": "pip3 install mobsf",
            "apkleaks": "pip3 install apkleaks",
            "objection": "pip3 install objection",
            "frida": "pip3 install frida-tools"
        },
        "Smart Contract Security Tools": {
            "mythril": "pip3 install mythril",
            "slither": "pip3 install slither-analyzer",
            "manticore": "pip3 install manticore"
        },
        "Cloud Security Tools": {
            "cloudsploit": "npm install -g cloudsploit",
            "prowler": "pip3 install prowler",
            "azuredumper": "pip3 install azure-cli"
        },
        "Dependency Tools": {
            "snyk": "npm install -g snyk"
        }
    }

    missing_tools = []

    print("\n=== Verifying Tool Installations ===\n")
    for category, category_tools in tools.items():
        print(f"\n{category}:")
        print("=" * (len(category) + 1))
        for tool, install_cmd in category_tools.items():
            if not check_tool(tool, install_cmd):
                missing_tools.append(tool)

    if missing_tools:
        print("\n❌ Missing Tools:")
        for tool in missing_tools:
            print(f"- {tool}")
        sys.exit(1)
    else:
        print("\n✅ All required tools are installed!")
        sys.exit(0)

if __name__ == "__main__":
    main()
