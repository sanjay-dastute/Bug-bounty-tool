#!/bin/bash
set -e

echo "Installing system dependencies..."
sudo apt-get update
sudo apt-get install -y build-essential python3-dev python3-pip nmap masscan nikto python3-venv

# Install Go
if ! command -v go &> /dev/null; then
    wget https://go.dev/dl/go1.21.8.linux-amd64.tar.gz
    sudo rm -rf /usr/local/go
    sudo tar -C /usr/local -xzf go1.21.8.linux-amd64.tar.gz
fi

# Add Go to PATH
export PATH=$PATH:/usr/local/go/bin
export GOPATH=$HOME/go
export PATH=$PATH:$GOPATH/bin

# Create and activate Python virtual environment
python3 -m venv venv
source venv/bin/activate

# Install Python packages with specific versions to avoid conflicts
pip install --upgrade pip
pip install "eth-hash==0.3.3"
pip install "eth-utils==2.3.2"
pip install "eth-abi==4.2.1"
pip install "hexbytes==0.2.3"
pip install "mythril==0.24.8"
pip install "slither-analyzer==0.9.3"
pip install "semgrep==1.86.0"

# Install Go tools
echo "Installing Go-based security tools..."
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/OWASP/Amass/v3/...@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest

# Install Node.js and Node-based tools
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
nvm install 18
nvm use 18
npm install -g apkleaks

echo "Installation complete. Running verification..."
python3 verify_complete.py
