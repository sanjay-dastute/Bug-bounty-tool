import subprocess
import sys
import os
import time
from typing import List, Tuple

def run_command(command: List[str], timeout: int = 300) -> Tuple[bool, str]:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0, result.stdout
    except subprocess.TimeoutExpired:
        return False, f"Command timed out after {timeout} seconds"
    except Exception as e:
        return False, str(e)

def install_go_tool(tool_path: str, timeout: int = 300) -> bool:
    print(f"Installing {tool_path}...")
    go_bin = "/usr/local/go/bin/go"
    success, output = run_command([go_bin, "install", "-v", tool_path + "@latest"], timeout)
    if success:
        print(f"✅ Successfully installed {tool_path}")
    else:
        print(f"❌ Failed to install {tool_path}: {output}")
    return success

def install_apt_tool(tool_name: str) -> bool:
    print(f"Installing {tool_name}...")
    success, _ = run_command(["sudo", "apt-get", "install", "-y", tool_name])
    if success:
        print(f"✅ Successfully installed {tool_name}")
    else:
        print(f"❌ Failed to install {tool_name}")
    return success

def install_pip_tool(tool_spec: str) -> bool:
    print(f"Installing {tool_spec}...")
    success, output = run_command(["python3", "-m", "pip", "install", "--no-cache-dir", tool_spec])
    if success:
        print(f"✅ Successfully installed {tool_spec}")
    else:
        print(f"❌ Failed to install {tool_spec}: {output}")
    return success

def main():
    # Set up environment
    os.environ["GOROOT"] = "/usr/local/go"
    os.environ["GOPATH"] = os.path.expanduser("~/go")
    os.environ["PATH"] = os.environ["PATH"] + ":" + os.environ["GOROOT"] + "/bin:" + os.environ["GOPATH"] + "/bin"

    # Update package lists
    print("Updating package lists...")
    run_command(["sudo", "apt-get", "update"])

    # Install Go tools
    go_tools = [
        "github.com/projectdiscovery/subfinder/v2/cmd/subfinder",
        "github.com/projectdiscovery/dnsx/cmd/dnsx",
        "github.com/projectdiscovery/nuclei/v3/cmd/nuclei",
        "github.com/OWASP/Amass/v3/..."
    ]

    # Install system tools
    apt_tools = ["nmap", "masscan", "nikto", "sqlmap"]

    # Install Python tools
    pip_tools = [
        "mythril==0.23.0",
        "slither-analyzer==0.9.3",
        "manticore==0.3.7",
        "prowler-cloud"
    ]

    print("\n=== Installing Go tools ===")
    for tool in go_tools:
        install_go_tool(tool)
        time.sleep(2)  # Add small delay between installations

    print("\n=== Installing system tools ===")
    for tool in apt_tools:
        install_apt_tool(tool)
        time.sleep(1)

    print("\n=== Installing Python tools ===")
    for tool in pip_tools:
        install_pip_tool(tool)
        time.sleep(1)

    print("\n=== Running verification script ===")
    success, output = run_command(["python3", "verify_tools_complete.py"])
    if success:
        print("✅ All tools verified successfully")
    else:
        print("❌ Verification failed:", output)
        sys.exit(1)

if __name__ == "__main__":
    main()
