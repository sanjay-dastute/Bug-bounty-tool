#!/bin/bash
set -e

echo "=== Installing Remaining Security Tools ==="

# Function to handle errors
handle_error() {
    echo "Error occurred in command: $1"
    echo "Continuing with next installation..."
}

# Install system dependencies
echo "Installing system dependencies..."
sudo apt-get update
sudo apt-get install -y python3-pip python3-dev build-essential libssl-dev libffi-dev || handle_error "apt dependencies"

# Install Python tools
echo "Installing Python-based tools..."
pip3 install --upgrade pip || handle_error "pip upgrade"

# Smart Contract Security Tools
echo "Installing Smart Contract tools..."
pip3 install manticore || handle_error "manticore install"

# Cloud Security Tools
echo "Installing Cloud Security tools..."
pip3 install ScoutSuite || handle_error "ScoutSuite install"
pip3 install prowler-cloud || handle_error "prowler-cloud install"
# Note: cloudsploit and azuredumper are not available via pip, using alternatives
pip3 install cloud-custodian || handle_error "cloud-custodian install"
pip3 install azure-security-scanner || handle_error "azure-security-scanner install"

# Reinstall Node.js tools
echo "Installing Node.js based tools..."
npm install -g snyk || handle_error "snyk install"
npm install -g whitesource || handle_error "whitesource install"

# Create necessary symlinks
echo "Creating tool symlinks..."
# Create Burp Suite symlink
if [ -f "/home/ubuntu/BurpSuiteCommunity/burpsuite" ]; then
    sudo ln -sf /home/ubuntu/BurpSuiteCommunity/burpsuite /usr/local/bin/burpsuite || handle_error "burpsuite symlink"
fi

# Create Scout Suite symlink
if [ -f "$HOME/.local/bin/scout" ]; then
    sudo ln -sf $HOME/.local/bin/scout /usr/local/bin/scout || handle_error "scout symlink"
fi

echo "=== Installation Complete ==="

# Verify installations
echo "=== Verifying New Installations ==="
python3 verify_tools_status_fixed.py

# Print installation summary
echo "=== Installation Summary ==="
echo "Installed tools:"
which burpsuite scout snyk 2>/dev/null || true
pip3 list | grep -E "manticore|ScoutSuite|prowler|cloud-custodian|azure-security-scanner" || true
npm list -g | grep -E "snyk|whitesource" || true
