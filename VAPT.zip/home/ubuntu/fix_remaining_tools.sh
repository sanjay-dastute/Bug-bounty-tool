#!/bin/bash
set -e

echo "=== Fixing Remaining Tool Issues ==="

# Function to handle errors
handle_error() {
    echo "Error occurred in command: $1"
    echo "Continuing with next installation..."
}

# Fix Burp Suite detection
echo "Fixing Burp Suite detection..."
if [ -f "/home/ubuntu/BurpSuiteCommunity/burpsuite" ]; then
    sudo chmod +x /home/ubuntu/BurpSuiteCommunity/burpsuite
    sudo ln -sf /home/ubuntu/BurpSuiteCommunity/burpsuite /usr/local/bin/burpsuite
fi

# Try alternative installation method for manticore
echo "Installing manticore via alternative method..."
python3 -m pip install --upgrade pip
python3 -m pip install manticore --no-deps
python3 -m pip install z3-solver
python3 -m pip install crytic-compile

# Install alternative cloud security tools
echo "Installing alternative cloud security tools..."
# Alternative to cloudsploit
pip3 install cloud-custodian || handle_error "cloud-custodian"
pip3 install cloudmapper || handle_error "cloudmapper"

# Alternative to azuredumper
pip3 install azure-cli || handle_error "azure-cli"
pip3 install azure-security-benchmark || handle_error "azure-security-benchmark"

echo "=== Fixes Complete ==="

# Verify installations again
echo "=== Verifying Tool Installations ==="
python3 verify_tools_status_fixed.py

# Print final tool status
echo "=== Final Tool Status ==="
echo "Checking specific tools:"
which burpsuite manticore 2>/dev/null || true
pip3 list | grep -E "manticore|cloud-custodian|cloudmapper|azure-cli|azure-security-benchmark" || true
