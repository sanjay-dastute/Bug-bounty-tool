import subprocess
import os
import re
from typing import Dict, List, Tuple

def check_tool(tool: str) -> bool:
    try:
        subprocess.run(['which', tool], check=True, capture_output=True)
        return True
    except subprocess.CalledProcessError:
        return False

def check_classification_systems(directory: str) -> List[str]:
    classification_terms = [
        'priority', 'severity', 'classification', 'criticality',
        'high risk', 'medium risk', 'low risk', 'cvss'
    ]
    findings = []

    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(('.py', '.tsx', '.ts', '.js', '.md')):
                filepath = os.path.join(root, file)
                try:
                    with open(filepath, 'r') as f:
                        content = f.read()
                        for term in classification_terms:
                            if re.search(rf'\b{term}\b', content, re.IGNORECASE):
                                findings.append(f"{filepath}: contains '{term}'")
                except Exception as e:
                    print(f"Error reading {filepath}: {e}")
    return findings

def main():
    # Tools to verify from the document
    tools = {
        'Reconnaissance': ['subfinder', 'amass', 'findomain', 'dnsx', 'altdns'],
        'Vulnerability Scanners': ['nmap', 'nuclei', 'sqlmap', 'semgrep', 'nikto', 'masscan'],
        'Mobile Security': ['mobsf', 'apkleaks', 'objection', 'frida'],
        'Smart Contract': ['mythril', 'slither', 'manticore'],
        'Cloud Security': ['prowler', 'cloudsploit']
    }

    print("=== Tool Installation Verification ===")
    for category, category_tools in tools.items():
        print(f"\n{category}:")
        for tool in category_tools:
            status = "✅" if check_tool(tool) else "❌"
            print(f"{status} {tool}")

    print("\n=== Classification System Check ===")
    findings = check_classification_systems('/home/ubuntu/Bug-bounty-tool')
    if findings:
        print("\n⚠️ Found potential classification systems:")
        for finding in findings:
            print(f"  - {finding}")
    else:
        print("✅ No classification systems found")

if __name__ == "__main__":
    main()
