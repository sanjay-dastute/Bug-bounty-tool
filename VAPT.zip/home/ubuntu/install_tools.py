#!/usr/bin/env python3
import subprocess
import sys
import os
from threading import Timer

def run_command_with_timeout(command, timeout=300):
    """Run command with timeout"""
    try:
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        timer = Timer(timeout, process.kill)
        try:
            timer.start()
            stdout, stderr = process.communicate()
            return process.returncode == 0, stdout.decode(), stderr.decode()
        finally:
            timer.cancel()
    except Exception as e:
        return False, "", str(e)

def install_tool(tool_name):
    """Install a specific tool with appropriate command"""
    print(f"\nInstalling {tool_name}...")

    install_commands = {
        # Reconnaissance Tools
        "subfinder": "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
        "amass": "go install -v github.com/owasp-amass/amass/v3/...@master",
        "findomain": "wget https://github.com/findomain/findomain/releases/latest/download/findomain-linux && chmod +x findomain-linux && sudo mv findomain-linux /usr/local/bin/findomain",
        "dnsx": "go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
        "altdns": "pip3 install py-altdns",

        # Vulnerability Scanners
        "nuclei": "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
        "semgrep": "pip3 install semgrep",

        # Mobile Security Tools
        "mobsf": "pip3 install mobsf",
        "apkleaks": "pip3 install apkleaks",
        "objection": "pip3 install objection",
        "frida": "pip3 install frida-tools",

        # Smart Contract Security Tools
        "mythril": "pip3 install mythril",
        "slither": "pip3 install slither-analyzer",
        "manticore": "pip3 install manticore",

        # Cloud Security Tools
        "cloudsploit": "npm install -g cloudsploit",
        "prowler": "pip3 install prowler",

        # Dependency Tools
        "snyk": "npm install -g snyk"
    }

    if tool_name not in install_commands:
        print(f"❌ No installation command found for {tool_name}")
        return False

    success, stdout, stderr = run_command_with_timeout(install_commands[tool_name])
    if success:
        print(f"✅ Successfully installed {tool_name}")
        return True
    else:
        print(f"❌ Failed to install {tool_name}")
        print(f"Error: {stderr}")
        return False

def main():
    # First verify which tools are missing
    print("=== Checking existing tools ===")
    missing_tools = []
    for tool in install_commands.keys():
        if not run_command_with_timeout(f"which {tool}")[0]:
            missing_tools.append(tool)

    if not missing_tools:
        print("✅ All tools are already installed!")
        return

    print("\n=== Installing missing tools ===")
    failed_installations = []
    for tool in missing_tools:
        if not install_tool(tool):
            failed_installations.append(tool)

    if failed_installations:
        print("\n❌ Failed to install the following tools:")
        for tool in failed_installations:
            print(f"- {tool}")
        sys.exit(1)
    else:
        print("\n✅ All tools installed successfully!")
        sys.exit(0)

if __name__ == "__main__":
    main()
