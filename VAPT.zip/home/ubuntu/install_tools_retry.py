import subprocess
import sys
import os
import time
from typing import List, Tuple

def run_command_with_retry(command: List[str], retries: int = 3, timeout: int = 120) -> Tuple[bool, str]:
    for attempt in range(retries):
        try:
            print(f"Attempt {attempt + 1}/{retries}")
            result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
            if result.returncode == 0:
                return True, result.stdout
            print(f"Command failed with: {result.stderr}")
        except subprocess.TimeoutExpired:
            print(f"Timeout after {timeout} seconds")
        except Exception as e:
            print(f"Error: {str(e)}")

        if attempt < retries - 1:
            print(f"Retrying in 5 seconds...")
            time.sleep(5)
    return False, "All attempts failed"

def install_go_tool(tool_path: str) -> bool:
    print(f"\nInstalling {tool_path}...")
    go_bin = "/usr/local/go/bin/go"
    success, output = run_command_with_retry([go_bin, "install", "-v", tool_path + "@latest"])
    if success:
        print(f"✅ Successfully installed {tool_path}")
    else:
        print(f"❌ Failed to install {tool_path}")
    return success

def install_apt_tool(tool_name: str) -> bool:
    print(f"\nInstalling {tool_name}...")
    success, _ = run_command_with_retry(["sudo", "apt-get", "install", "-y", tool_name])
    if success:
        print(f"✅ Successfully installed {tool_name}")
    else:
        print(f"❌ Failed to install {tool_name}")
    return success

def install_pip_tool(tool_spec: str) -> bool:
    print(f"\nInstalling {tool_spec}...")
    success, output = run_command_with_retry(
        ["python3", "-m", "pip", "install", "--no-cache-dir", tool_spec]
    )
    if success:
        print(f"✅ Successfully installed {tool_spec}")
    else:
        print(f"❌ Failed to install {tool_spec}")
    return success

def main():
    # Set up environment
    os.environ["GOROOT"] = "/usr/local/go"
    os.environ["GOPATH"] = os.path.expanduser("~/go")
    os.environ["PATH"] = f"{os.environ['PATH']}:{os.environ['GOROOT']}/bin:{os.environ['GOPATH']}/bin"

    # Update package lists
    print("Updating package lists...")
    run_command_with_retry(["sudo", "apt-get", "update"])

    # Define tools to install
    go_tools = [
        "github.com/projectdiscovery/subfinder/v2/cmd/subfinder",
        "github.com/projectdiscovery/dnsx/cmd/dnsx",
        "github.com/projectdiscovery/nuclei/v3/cmd/nuclei",
        "github.com/OWASP/Amass/v3/..."
    ]

    apt_tools = ["nmap", "masscan", "nikto", "sqlmap"]

    pip_tools = [
        "mythril==0.23.0",
        "slither-analyzer==0.9.3",
        "manticore==0.3.7",
        "prowler-cloud"
    ]

    # Track installation success
    failed_installations = []

    # Install Go tools
    print("\n=== Installing Go tools ===")
    for tool in go_tools:
        if not install_go_tool(tool):
            failed_installations.append(tool)

    # Install system tools
    print("\n=== Installing system tools ===")
    for tool in apt_tools:
        if not install_apt_tool(tool):
            failed_installations.append(tool)

    # Install Python tools
    print("\n=== Installing Python tools ===")
    for tool in pip_tools:
        if not install_pip_tool(tool):
            failed_installations.append(tool)

    # Report results
    if failed_installations:
        print("\n❌ The following tools failed to install:")
        for tool in failed_installations:
            print(f"  - {tool}")
        sys.exit(1)
    else:
        print("\n✅ All tools installed successfully")
        print("\n=== Running verification script ===")
        success, _ = run_command_with_retry(["python3", "verify_tools_complete.py"])
        if not success:
            print("❌ Verification failed")
            sys.exit(1)
        print("✅ All tools verified successfully")

if __name__ == "__main__":
    main()
