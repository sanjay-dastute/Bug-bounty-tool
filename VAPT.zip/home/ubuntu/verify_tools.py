#!/usr/bin/env python3
import subprocess
import shutil
import sys
from typing import Dict, List, Tuple

def run_command(command: str) -> Tuple[bool, str]:
    try:
        result = subprocess.run(command.split(), capture_output=True, text=True)
        return True, result.stdout
    except Exception as e:
        return False, str(e)

def check_tool(name: str, command: str) -> bool:
    # First check if tool exists in PATH
    if shutil.which(name):
        return True

    # Try running the verification command
    success, _ = run_command(command)
    return success

def verify_tools() -> Dict[str, Dict[str, List[Tuple[str, bool]]]]:
    tools = {
        "Reconnaissance": {
            "description": "Tools for subdomain and asset discovery",
            "tools": [
                ("subfinder", "subfinder -version"),
                ("amass", "amass -version"),
                ("assetfinder", "which assetfinder"),
                ("findomain", "findomain --version"),
                ("altdns", "which altdns"),
                ("dnsx", "dnsx -version")
            ]
        },
        "Vulnerability Scanners": {
            "description": "Core vulnerability scanning tools",
            "tools": [
                ("nmap", "nmap --version"),
                ("burpsuite", "which burpsuite"),
                ("zaproxy", "which zaproxy"),
                ("nuclei", "nuclei -version"),
                ("sqlmap", "sqlmap --version"),
                ("semgrep", "semgrep --version"),
                ("nikto", "nikto -Version"),
                ("masscan", "masscan --version")
            ]
        },
        "Mobile Security": {
            "description": "Mobile application security tools",
            "tools": [
                ("mobsf", "which mobsf"),
                ("apkleaks", "which apkleaks"),
                ("objection", "objection --version"),
                ("frida", "frida --version")
            ]
        },
        "Smart Contract Security": {
            "description": "Blockchain and smart contract analysis tools",
            "tools": [
                ("mythril", "myth version"),
                ("slither", "slither --version"),
                ("manticore", "manticore --version")
            ]
        },
        "Cloud Security": {
            "description": "Cloud infrastructure security tools",
            "tools": [
                ("cloudsploit", "which cloudsploit"),
                ("scout", "which scout"),
                ("prowler", "prowler --version"),
                ("azuredumper", "which azuredumper")
            ]
        },
        "Dependency Security": {
            "description": "Dependency and library vulnerability scanners",
            "tools": [
                ("snyk", "snyk --version"),
                ("whitesource", "which whitesource")
            ]
        }
    }

    results = {}

    print("\nVerifying tool installations...\n")

    for category, info in tools.items():
        results[category] = []
        print(f"\n=== {category} ===")
        print(f"Description: {info['description']}")

        for tool_name, check_command in info["tools"]:
            is_installed = check_tool(tool_name, check_command)
            results[category].append((tool_name, is_installed))
            status = "✅ Installed" if is_installed else "❌ Not Found"
            print(f"{tool_name}: {status}")

    return results

def main():
    results = verify_tools()

    # Print summary
    print("\n=== Installation Summary ===")
    total_tools = sum(len(tools) for tools in [cat for cat in results.values()])
    installed_tools = sum(
        sum(1 for tool in cat if tool[1])
        for cat in results.values()
    )

    print(f"\nTotal tools required: {total_tools}")
    print(f"Tools installed: {installed_tools}")
    print(f"Tools missing: {total_tools - installed_tools}")

    if total_tools - installed_tools > 0:
        print("\nMissing tools:")
        for category, tools in results.items():
            missing = [tool[0] for tool in tools if not tool[1]]
            if missing:
                print(f"\n{category}:")
                for tool in missing:
                    print(f"  - {tool}")

if __name__ == "__main__":
    main()
