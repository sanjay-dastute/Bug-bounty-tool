#!/bin/bash
set -e

echo "=== Installing Missing Security Tools ==="

# Function to handle errors
handle_error() {
    echo "Error occurred in command: $1"
    echo "Continuing with next installation..."
}

# Install system dependencies
echo "Installing system dependencies..."
sudo apt-get update
sudo apt-get install -y default-jdk python3-pip masscan || handle_error "apt-get install"

# Setup Node.js using nvm
echo "Setting up Node.js..."
. ~/.nvm/nvm.sh
nvm install 18 || handle_error "nvm install"
nvm use 18 || handle_error "nvm use"

# Install Go tools
echo "Installing Go-based tools..."
export GOPATH=$HOME/go
export PATH=$PATH:$GOPATH/bin

go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest || handle_error "subfinder install"
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest || handle_error "dnsx install"
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest || handle_error "nuclei install"
go install -v github.com/tomnomnom/assetfinder@latest || handle_error "assetfinder install"

# Install Python tools
echo "Installing Python-based tools..."
pip3 install --upgrade pip || handle_error "pip upgrade"
for tool in mythril slither-analyzer manticore objection scout-suite; do
    pip3 install $tool || handle_error "pip install $tool"
done

# Install Cloud Security tools
echo "Installing Cloud Security tools..."
for tool in prowler cloudsploit azuredumper; do
    pip3 install $tool || handle_error "pip install $tool"
done

# Install Node.js based tools
echo "Installing Node.js based tools..."
npm install -g snyk || handle_error "npm install snyk"
npm install -g whitesource || handle_error "npm install whitesource"

# Install OWASP ZAP
echo "Installing OWASP ZAP..."
if [ ! -f "ZAP_2.14.0_Linux.tar.gz" ]; then
    wget -q https://github.com/zaproxy/zaproxy/releases/download/v2.14.0/ZAP_2.14.0_Linux.tar.gz || handle_error "ZAP download"
fi
tar -xf ZAP_2.14.0_Linux.tar.gz || handle_error "ZAP extract"
sudo mv ZAP_2.14.0 /opt/zaproxy 2>/dev/null || handle_error "ZAP move"
sudo ln -sf /opt/zaproxy/zap.sh /usr/local/bin/zap || handle_error "ZAP symlink"

# Install Burp Suite Community Edition
echo "Installing Burp Suite Community Edition..."
if [ ! -f "burpsuite_community.sh" ]; then
    wget -q "https://portswigger.net/burp/releases/download?product=community&version=2023.10.1.2&type=Linux" -O burpsuite_community.sh || handle_error "Burp Suite download"
fi
chmod +x burpsuite_community.sh
./burpsuite_community.sh -q || handle_error "Burp Suite install"

# Clean up temporary files
echo "Cleaning up..."
rm -f ZAP_2.14.0_Linux.tar.gz burpsuite_community.sh

echo "=== Installation Complete ==="

# Verify installations
echo "=== Verifying New Installations ==="
python3 verify_tools_status.py

# Print summary of installations
echo "=== Installation Summary ==="
echo "Installed tools:"
which masscan subfinder dnsx nuclei assetfinder zap 2>/dev/null || true
pip3 list | grep -E "mythril|slither|manticore|objection|scout|prowler|cloudsploit|azuredumper" || true
npm list -g | grep -E "snyk|whitesource" || true
