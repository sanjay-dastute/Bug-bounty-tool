#!/bin/bash
set -e

echo "Installing all required security tools..."

# Update package lists
sudo apt-get update

# Install system dependencies
sudo apt-get install -y build-essential python3-dev python3-pip nmap masscan nikto

# Install Go if not present
if ! command -v go &> /dev/null; then
    wget https://go.dev/dl/go1.21.8.linux-amd64.tar.gz
    sudo rm -rf /usr/local/go
    sudo tar -C /usr/local -xzf go1.21.8.linux-amd64.tar.gz
    export PATH=$PATH:/usr/local/go/bin
fi

# Create Python virtual environment
python3 -m venv venv
source venv/bin/activate

# Install Python-based tools
pip install --upgrade pip
pip install "mythril==0.24.8"
pip install "slither-analyzer==0.9.3"
pip install "manticore==0.3.7"
pip install "semgrep==1.86.0"
pip install "mobsf==3.7.7"
pip install "cloudsploit"
pip install "prowler"
pip install "snyk"

# Install Go-based tools
echo "Installing Go tools..."
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/OWASP/Amass/v3/...@latest
go install -v github.com/tomnomnom/assetfinder@latest
go install -v github.com/findomain/findomain@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go install -v github.com/sqlmapproject/sqlmap@latest

# Install Node.js based tools
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
nvm install 18
nvm use 18
npm install -g apkleaks

# Install Frida
pip install frida-tools

# Install additional tools
pip install scout-suite
pip install azure-cli

echo "Installation complete. Running verification..."
