import subprocess
import os
import re
from typing import List, Dict, Tuple

def run_command(command: List[str], timeout: int = 30) -> Tuple[bool, str]:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0, result.stdout
    except Exception as e:
        return False, str(e)

def check_tool_version(tool: str) -> bool:
    """Check if a tool is installed and get its version."""
    commands = {
        # Reconnaissance Tools
        "subfinder": ["subfinder", "-version"],
        "amass": ["amass", "version"],
        "dnsx": ["dnsx", "-version"],

        # Vulnerability Scanners
        "nmap": ["nmap", "--version"],
        "nuclei": ["nuclei", "-version"],
        "sqlmap": ["sqlmap", "--version"],
        "nikto": ["nikto", "-Version"],
        "masscan": ["masscan", "--version"],

        # Mobile Security
        "mobsf": ["docker", "images", "opensecurity/mobile-security-framework-mobsf"],

        # Smart Contract Tools
        "mythril": ["myth", "version"],
        "slither": ["slither", "--version"],
        "manticore": ["manticore", "--version"],

        # Cloud Security
        "prowler": ["prowler", "--version"]
    }

    if tool not in commands:
        return False

    success, output = run_command(commands[tool])
    return success

def check_python_package(package: str) -> bool:
    """Check if a Python package is installed."""
    try:
        __import__(package)
        return True
    except ImportError:
        return False

def check_classification_system() -> List[str]:
    """Check for any unauthorized classification or priority systems."""
    suspicious_terms = [
        r"priority.*classification",
        r"severity.*level",
        r"risk.*rating",
        r"vulnerability.*score",
        r"priority.*level",
        r"high.*medium.*low",
        r"critical.*high.*medium.*low"
    ]

    findings = []

    # Define directories to search
    search_dirs = [
        "/home/ubuntu/Bug-bounty-tool/backend",
        "/home/ubuntu/Bug-bounty-tool/frontend",
        "/home/ubuntu/Bug-bounty-tool/docs"
    ]

    for directory in search_dirs:
        if not os.path.exists(directory):
            continue

        for root, _, files in os.walk(directory):
            for file in files:
                if file.endswith(('.py', '.js', '.tsx', '.ts', '.md')):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            content = f.read()
                            for term in suspicious_terms:
                                if re.search(term, content, re.IGNORECASE):
                                    findings.append(f"Found classification system in {file_path}: {term}")
                    except Exception as e:
                        print(f"Warning: Could not read file {file_path}: {str(e)}")

    return findings

def main():
    print("=== Checking Tool Installations ===\n")

    tools = {
        "Reconnaissance Tools": ["subfinder", "amass", "dnsx"],
        "Vulnerability Scanners": ["nmap", "nuclei", "sqlmap", "nikto", "masscan"],
        "Mobile Security": ["mobsf"],
        "Smart Contract Tools": ["mythril", "slither", "manticore"],
        "Cloud Security": ["prowler"]
    }

    missing_tools = []

    for category, category_tools in tools.items():
        print(f"\n{category}:")
        for tool in category_tools:
            if check_tool_version(tool):
                print(f"✅ {tool} is installed")
            else:
                print(f"❌ {tool} is NOT installed")
                missing_tools.append(tool)

    print("\n=== Checking for Classification Systems ===\n")
    classification_findings = check_classification_system()

    if classification_findings:
        print("❌ Found unauthorized classification systems:")
        for finding in classification_findings:
            print(f"  - {finding}")
    else:
        print("✅ No unauthorized classification systems found")

    if missing_tools:
        print("\n❌ The following tools are missing:")
        for tool in missing_tools:
            print(f"  - {tool}")
        return 1

    if classification_findings:
        return 1

    print("\n✅ All required tools are installed and no unauthorized classification systems found")
    return 0

if __name__ == "__main__":
    exit(main())
