#!/usr/bin/env python3
import subprocess
import sys
import os
from threading import Timer
import glob

def run_command_with_timeout(command, timeout=300):
    """Run command with timeout"""
    try:
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        timer = Timer(timeout, process.kill)
        try:
            timer.start()
            stdout, stderr = process.communicate()
            return process.returncode == 0, stdout.decode(), stderr.decode()
        finally:
            timer.cancel()
    except Exception as e:
        return False, "", str(e)

def check_classification_systems():
    """Check for classification systems in the codebase"""
    print("\n=== Checking for Classification Systems ===")

    # Get all relevant files
    file_patterns = ['**/*.py', '**/*.tsx', '**/*.ts', '**/*.js']
    classification_terms = ['priority', 'severity', 'classification', 'criticality']

    found_classifications = []

    for pattern in file_patterns:
        for file in glob.glob(pattern, recursive=True):
            try:
                with open(file, 'r') as f:
                    content = f.read().lower()
                    for term in classification_terms:
                        if term in content:
                            found_classifications.append(f"{file}: contains '{term}'")
            except Exception as e:
                print(f"Error reading {file}: {str(e)}")

    return found_classifications

def verify_tools():
    """Verify and install required tools"""
    tools = {
        "Reconnaissance Tools": {
            "subfinder": "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
            "amass": "go install -v github.com/owasp-amass/amass/v3/...@master",
            "findomain": "wget https://github.com/findomain/findomain/releases/latest/download/findomain-linux && chmod +x findomain-linux && sudo mv findomain-linux /usr/local/bin/findomain",
            "dnsx": "go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest",
            "altdns": "pip3 install py-altdns"
        },
        "Vulnerability Scanners": {
            "nmap": "sudo apt-get install -y nmap",
            "nuclei": "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
            "sqlmap": "sudo apt-get install -y sqlmap",
            "semgrep": "pip3 install semgrep",
            "nikto": "sudo apt-get install -y nikto",
            "masscan": "sudo apt-get install -y masscan"
        },
        "Mobile Security Tools": {
            "mobsf": "pip3 install mobsf",
            "apkleaks": "pip3 install apkleaks",
            "objection": "pip3 install objection",
            "frida": "pip3 install frida-tools"
        },
        "Smart Contract Tools": {
            "mythril": "pip3 install mythril",
            "slither": "pip3 install slither-analyzer",
            "manticore": "pip3 install manticore"
        },
        "Cloud Security Tools": {
            "cloudsploit": "npm install -g cloudsploit",
            "prowler": "pip3 install prowler"
        },
        "Dependency Tools": {
            "snyk": "npm install -g snyk"
        }
    }

    missing_tools = []
    installed_tools = []

    print("\n=== Verifying Tool Installations ===")
    for category, category_tools in tools.items():
        print(f"\n{category}:")
        print("=" * (len(category) + 1))
        for tool, install_cmd in category_tools.items():
            success, _, _ = run_command_with_timeout(f"which {tool}")
            if not success:
                print(f"Installing {tool}...")
                install_success, _, stderr = run_command_with_timeout(install_cmd)
                if install_success:
                    installed_tools.append(tool)
                    print(f"✅ {tool} installed successfully")
                else:
                    missing_tools.append(tool)
                    print(f"❌ Failed to install {tool}: {stderr}")
            else:
                installed_tools.append(tool)
                print(f"✅ {tool} already installed")

    return installed_tools, missing_tools

def main():
    # Verify and install tools
    installed_tools, missing_tools = verify_tools()

    # Check for classification systems
    classification_findings = check_classification_systems()

    # Print summary
    print("\n=== Summary ===")
    print(f"\nSuccessfully installed/verified tools: {len(installed_tools)}")
    for tool in installed_tools:
        print(f"✅ {tool}")

    if missing_tools:
        print(f"\nFailed to install tools: {len(missing_tools)}")
        for tool in missing_tools:
            print(f"❌ {tool}")

    if classification_findings:
        print("\nFound classification systems:")
        for finding in classification_findings:
            print(f"⚠️ {finding}")
    else:
        print("\n✅ No classification systems found in codebase")

    if missing_tools or classification_findings:
        sys.exit(1)
    else:
        sys.exit(0)

if __name__ == "__main__":
    main()
