import subprocess
import sys
import os
import time
import requests
import tarfile
import zipfile
from pathlib import Path
from typing import List, Tuple

def run_command(command: List[str], timeout: int = 60) -> Tuple[bool, str]:
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
        return result.returncode == 0, result.stdout
    except subprocess.TimeoutExpired:
        return False, f"Command timed out after {timeout} seconds"
    except Exception as e:
        return False, str(e)

def download_file(url: str, dest_path: str) -> bool:
    try:
        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()
        with open(dest_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        return True
    except Exception as e:
        print(f"Download failed: {str(e)}")
        return False

def install_binary_tool(name: str, url: str, bin_path: str) -> bool:
    print(f"\nInstalling {name}...")
    download_path = f"/tmp/{name}_download"

    # Download the binary
    if not download_file(url, download_path):
        return False

    # Extract if needed and move to bin location
    try:
        if url.endswith('.tar.gz'):
            with tarfile.open(download_path, 'r:gz') as tar:
                tar.extractall('/tmp')
        elif url.endswith('.zip'):
            with zipfile.ZipFile(download_path, 'r') as zip_ref:
                zip_ref.extractall('/tmp')

        # Move binary to bin location
        os.makedirs(os.path.dirname(bin_path), exist_ok=True)
        if os.path.exists(download_path):
            subprocess.run(['sudo', 'mv', download_path, bin_path])
        subprocess.run(['sudo', 'chmod', '+x', bin_path])

        print(f"✅ Successfully installed {name}")
        return True
    except Exception as e:
        print(f"❌ Failed to install {name}: {str(e)}")
        return False

def install_apt_tool(tool_name: str) -> bool:
    print(f"\nInstalling {tool_name}...")
    success, _ = run_command(["sudo", "apt-get", "install", "-y", tool_name])
    if success:
        print(f"✅ Successfully installed {tool_name}")
    else:
        print(f"❌ Failed to install {tool_name}")
    return success

def install_pip_tool(tool_spec: str) -> bool:
    print(f"\nInstalling {tool_spec}...")
    success, _ = run_command(["python3", "-m", "pip", "install", "--no-cache-dir", tool_spec])
    if success:
        print(f"✅ Successfully installed {tool_spec}")
    else:
        print(f"❌ Failed to install {tool_spec}")
    return success

def main():
    # Update package lists
    print("Updating package lists...")
    run_command(["sudo", "apt-get", "update"])

    # Define binary tools to install
    binary_tools = {
        "subfinder": ("https://github.com/projectdiscovery/subfinder/releases/latest/download/subfinder_2.6.3_linux_amd64.tar.gz",
                     "/usr/local/bin/subfinder"),
        "dnsx": ("https://github.com/projectdiscovery/dnsx/releases/latest/download/dnsx_1.1.6_linux_amd64.tar.gz",
                "/usr/local/bin/dnsx"),
        "nuclei": ("https://github.com/projectdiscovery/nuclei/releases/latest/download/nuclei_2.9.14_linux_amd64.zip",
                  "/usr/local/bin/nuclei"),
        "amass": ("https://github.com/OWASP/Amass/releases/latest/download/amass_Linux_amd64.zip",
                 "/usr/local/bin/amass")
    }

    apt_tools = ["nmap", "masscan", "nikto", "sqlmap"]
    pip_tools = [
        "mythril==0.23.0",
        "slither-analyzer==0.9.3",
        "manticore==0.3.7",
        "prowler-cloud"
    ]

    failed_installations = []

    # Install binary tools
    print("\n=== Installing binary tools ===")
    for name, (url, bin_path) in binary_tools.items():
        if not install_binary_tool(name, url, bin_path):
            failed_installations.append(name)

    # Install system tools
    print("\n=== Installing system tools ===")
    for tool in apt_tools:
        if not install_apt_tool(tool):
            failed_installations.append(tool)

    # Install Python tools
    print("\n=== Installing Python tools ===")
    for tool in pip_tools:
        if not install_pip_tool(tool):
            failed_installations.append(tool)

    # Report results
    if failed_installations:
        print("\n❌ The following tools failed to install:")
        for tool in failed_installations:
            print(f"  - {tool}")
        sys.exit(1)
    else:
        print("\n✅ All tools installed successfully")
        print("\n=== Running verification script ===")
        success, _ = run_command(["python3", "verify_tools_complete.py"])
        if not success:
            print("❌ Verification failed")
            sys.exit(1)
        print("✅ All tools verified successfully")

if __name__ == "__main__":
    main()
