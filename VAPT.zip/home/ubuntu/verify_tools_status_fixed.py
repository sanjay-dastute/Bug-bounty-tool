#!/usr/bin/env python3
import subprocess
import os
import re
from pathlib import Path

def run_command(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        return result.stdout.strip()
    except Exception as e:
        return ""

def check_tool_exists(tool):
    # Check different installation methods
    paths = [
        f"/usr/bin/{tool}",
        f"/usr/local/bin/{tool}",
        f"{os.path.expanduser('~')}/go/bin/{tool}",
        f"{os.path.expanduser('~')}/BurpSuiteCommunity/{tool}",
    ]

    # Check if tool exists in PATH
    if run_command(f"which {tool}"):
        return True

    # Check specific paths
    for path in paths:
        if os.path.exists(path):
            return True

    # Check pip installations
    pip_list = run_command("pip3 list")
    if re.search(rf"{tool}(?:-analyzer)?\s+\d", pip_list, re.IGNORECASE):
        return True

    # Check npm global installations
    npm_list = run_command("npm list -g")
    if re.search(rf"{tool}@", npm_list, re.IGNORECASE):
        return True

    return False

def check_classification_systems():
    exclude_dirs = {'node_modules', 'venv', '.git', '__pycache__', 'dist', 'build'}
    classifications = []

    for root, dirs, files in os.walk('/home/ubuntu/Bug-bounty-tool'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]

        for file in files:
            if file.endswith(('.py', '.ts', '.tsx', '.js', '.jsx')):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8') as f:
                    try:
                        content = f.read()
                        # Only look for actual classification systems, not UI styling
                        if 'severity=' in content and 'Alert' not in content:
                            classifications.append(f"{filepath}: contains classification system")
                    except:
                        continue

    return classifications

def main():
    tools = {
        'subfinder': 'Go',
        'amass': 'Go',
        'findomain': 'Go',
        'dnsx': 'Go',
        'altdns': 'Python',
        'assetfinder': 'Go',
        'nmap': 'System',
        'nuclei': 'Go',
        'sqlmap': 'Python',
        'semgrep': 'Python',
        'nikto': 'System',
        'masscan': 'System',
        'zap': 'Java',
        'burpsuite': 'Java',
        'mobsf': 'Python',
        'apkleaks': 'Python',
        'objection': 'Python',
        'frida': 'Python',
        'mythril': 'Python',
        'slither': 'Python',
        'manticore': 'Python',
        'cloudsploit': 'Python',
        'prowler': 'Python',
        'scout': 'Python',
        'azuredumper': 'Python',
        'snyk': 'Node',
        'whitesource': 'Node',
        'python3': 'System',
        'go': 'System',
        'node': 'System',
        'npm': 'System'
    }

    print("\nChecking installed tools...")
    print("-" * 50)

    installed = []
    missing = []

    for tool, category in tools.items():
        if check_tool_exists(tool):
            print(f"[✓] {tool:<20} (installed)")
            installed.append(tool)
        else:
            print(f"[✗] {tool:<20} (not found)")
            missing.append(tool)

    print("\nChecking for classification systems in application code...")
    print("-" * 50)
    classifications = check_classification_systems()

    print("\nSummary:")
    print(f"Total tools checked: {len(tools)}")
    print(f"Installed: {len(installed)}")
    print(f"Missing: {len(missing)}")

    if missing:
        print("\nMissing tools:")
        for tool in missing:
            print(f"- {tool}")

    if classifications:
        print("\nClassification systems found in application code:")
        for classification in classifications:
            print(f"- {classification}")

if __name__ == "__main__":
    main()
