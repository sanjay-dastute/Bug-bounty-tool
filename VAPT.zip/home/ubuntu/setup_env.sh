#!/bin/bash

# Set up Go environment
export GOROOT=/usr/lib/go-1.19
export GOPATH=$HOME/go
export PATH=$PATH:$GOROOT/bin:$GOPATH/bin

# Create Go workspace directories
mkdir -p $GOPATH/src $GOPATH/bin $GOPATH/pkg

# Install reconnaissance tools
echo "=== Installing Reconnaissance Tools ==="
go install -v github.com/owasp-amass/amass/v3/...@master
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest

# Install findomain
wget -O findomain https://github.com/findomain/findomain/releases/latest/download/findomain-linux-amd64
chmod +x findomain
sudo mv findomain /usr/local/bin/

# Install vulnerability scanners
echo "=== Installing Vulnerability Scanners ==="
sudo apt-get update
sudo apt-get install -y nmap nikto masscan
pip3 install --user semgrep
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest

# Install sqlmap
git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git
sudo ln -sf $(pwd)/sqlmap/sqlmap.py /usr/local/bin/sqlmap
sudo chmod +x /usr/local/bin/sqlmap

# Make environment permanent
echo 'export GOROOT=/usr/lib/go-1.19' >> ~/.bashrc
echo 'export GOPATH=$HOME/go' >> ~/.bashrc
echo 'export PATH=$PATH:$GOROOT/bin:$GOPATH/bin' >> ~/.bashrc
