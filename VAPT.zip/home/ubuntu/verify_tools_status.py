#!/usr/bin/env python3
import subprocess
import shutil
import os
import re

def run_command(command):
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        return result.returncode == 0, result.stdout
    except Exception as e:
        return False, str(e)

def check_tool(name, command):
    exists, output = run_command(command)
    print(f"[{'✓' if exists else '✗'}] {name:<20} {'(installed)' if exists else '(not found)'}")
    return exists

def check_classification_systems(directory):
    classification_patterns = [
        r'priority\s*[=:]\s*[\'"]\w+[\'"]',
        r'severity\s*[=:]\s*[\'"]\w+[\'"]',
        r'classification\s*[=:]\s*[\'"]\w+[\'"]',
        r'criticality\s*[=:]\s*[\'"]\w+[\'"]'
    ]

    found_patterns = []
    for root, _, files in os.walk(directory):
        # Skip dependency directories
        if any(x in root for x in ['node_modules', 'venv', '.git', '__pycache__', 'dist']):
            continue

        for file in files:
            if file.endswith(('.py', '.js', '.ts', '.tsx', '.md', '.json')):
                filepath = os.path.join(root, file)
                try:
                    with open(filepath, 'r') as f:
                        content = f.read()
                        for pattern in classification_patterns:
                            matches = re.finditer(pattern, content, re.IGNORECASE)
                            for match in matches:
                                found_patterns.append((filepath, match.group(0)))
                except Exception as e:
                    print(f"Error reading {filepath}: {str(e)}")

    return found_patterns

def main():
    tools = {
        # Reconnaissance Tools
        'subfinder': 'subfinder -version',
        'amass': 'amass -version',
        'findomain': 'findomain --version',
        'dnsx': 'dnsx -version',
        'altdns': 'which altdns',
        'assetfinder': 'which assetfinder',

        # Vulnerability Scanners
        'nmap': 'nmap --version',
        'nuclei': 'nuclei -version',
        'sqlmap': 'sqlmap --version',
        'semgrep': 'semgrep --version',
        'nikto': 'nikto -Version',
        'masscan': 'masscan --version',
        'zap': 'which zap',
        'burpsuite': 'which burpsuite',

        # Mobile Security Tools
        'mobsf': 'python3 -c "import mobsf"',
        'apkleaks': 'apkleaks -h',
        'objection': 'objection --version',
        'frida': 'frida --version',

        # Smart Contract Tools
        'mythril': 'myth version',
        'slither': 'slither --version',
        'manticore': 'manticore --version',

        # Cloud Security Tools
        'cloudsploit': 'cloudsploit --version',
        'prowler': 'prowler --version',
        'scout': 'scout --version',
        'azuredumper': 'which azuredumper',

        # Dependency Tools
        'snyk': 'snyk --version',
        'whitesource': 'which whitesource',

        # Base Requirements
        'python3': 'python3 --version',
        'go': 'go version',
        'node': 'node --version',
        'npm': 'npm --version'
    }

    print("\nChecking installed tools...")
    print("-" * 50)

    installed = []
    missing = []

    for tool, command in tools.items():
        if check_tool(tool, command):
            installed.append(tool)
        else:
            missing.append(tool)

    print("\nChecking for classification systems in application code...")
    print("-" * 50)
    print("(Excluding node_modules, venv, and other dependency directories)")

    classification_findings = check_classification_systems('/home/ubuntu/Bug-bounty-tool')

    print("\nSummary:")
    print(f"Total tools checked: {len(tools)}")
    print(f"Installed: {len(installed)}")
    print(f"Missing: {len(missing)}")

    if missing:
        print("\nMissing tools:")
        for tool in missing:
            print(f"- {tool}")

    if classification_findings:
        print("\nClassification systems found in application code:")
        for file, pattern in classification_findings:
            print(f"- {file}: {pattern}")
    else:
        print("\nNo classification systems found in application code.")

if __name__ == "__main__":
    main()
