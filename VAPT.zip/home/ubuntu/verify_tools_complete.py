import subprocess
import sys
import os
from typing import List, Tuple

def run_command(command: List[str]) -> Tuple[bool, str]:
    try:
        result = subprocess.run(command, capture_output=True, text=True)
        return result.returncode == 0, result.stdout
    except Exception as e:
        return False, str(e)

def check_tool_version(tool: str, version_flag: str = "--version") -> Tuple[bool, str]:
    success, output = run_command([tool, version_flag])
    return success, output.strip() if success else f"Failed to get version: {output}"

def main():
    tools_to_check = [
        # Go-based tools
        ("subfinder", "--version"),
        ("dnsx", "--version"),
        ("nuclei", "--version"),
        ("amass", "--version"),

        # Python-based tools
        ("myth", "--version"),
        ("slither", "--version"),
        ("manticore", "--version"),
        ("prowler", "--version"),

        # System tools
        ("nmap", "--version"),
        ("masscan", "--version"),
        ("nikto", "-Version"),
        ("sqlmap", "--version")
    ]

    print("=== Checking Tool Installations ===")
    all_tools_installed = True

    for tool, version_flag in tools_to_check:
        success, version = check_tool_version(tool, version_flag)
        if success:
            print(f"✅ {tool}: {version.split()[0]}")
        else:
            print(f"❌ {tool}: Not found or not working")
            all_tools_installed = False

    print("\n=== Checking Go Installation ===")
    success, go_version = check_tool_version("go", "version")
    if success:
        print(f"✅ Go: {go_version}")
    else:
        print("❌ Go: Not found or not working")
        all_tools_installed = False

    print("\n=== Checking Classification Systems ===")
    classification_terms = [
        "priority",
        "severity",
        "classification",
        "criticality",
        "risk level",
        "impact level"
    ]

    codebase_path = "/home/ubuntu/Bug-bounty-tool"
    found_classifications = []

    for root, _, files in os.walk(codebase_path):
        for file in files:
            if file.endswith(('.py', '.tsx', '.ts', '.js', '.md', '.json')):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'r') as f:
                        content = f.read().lower()
                        for term in classification_terms:
                            if term in content:
                                found_classifications.append((file_path, term))
                except Exception:
                    continue

    if found_classifications:
        print("\n⚠️ Found classification systems in:")
        for file_path, term in found_classifications:
            print(f"  - {file_path} (term: {term})")
        all_tools_installed = False
    else:
        print("\n✅ No classification systems found")

    if not all_tools_installed:
        print("\n❌ Some tools are missing or classification systems were found")
        sys.exit(1)
    else:
        print("\n✅ All tools installed and no classification systems found")
        sys.exit(0)

if __name__ == "__main__":
    main()
