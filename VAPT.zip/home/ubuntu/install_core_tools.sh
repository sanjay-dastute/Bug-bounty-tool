#!/bin/bash
set -e

echo "Installing core security tools..."

# Update package lists
sudo apt-get update

# Install system dependencies
sudo apt-get install -y build-essential python3-dev python3-pip

# Install Go if not present
if ! command -v go &> /dev/null; then
    wget https://go.dev/dl/go1.21.8.linux-amd64.tar.gz
    sudo rm -rf /usr/local/go
    sudo tar -C /usr/local -xzf go1.21.8.linux-amd64.tar.gz
    export PATH=$PATH:/usr/local/go/bin
fi

# Create Python virtual environment
python3 -m venv venv
source venv/bin/activate

# Install core Python packages with specific versions
pip install --upgrade pip
pip install "mythril==0.24.8"
pip install "slither-analyzer==0.9.3"
pip install "manticore==0.3.7"

# Install Go tools
go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest

echo "Core tools installation complete."
